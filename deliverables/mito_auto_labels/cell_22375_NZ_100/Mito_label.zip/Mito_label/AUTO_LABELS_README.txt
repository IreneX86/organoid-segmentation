Automated Mito 2D semantic segmentation predictions — 2026-10-08

These 100 TIFFs are model-generated masks, NOT manually verified ground truth.
Each Mito_NNN.tif corresponds pixel-for-pixel to ../Mito/Mito_NNN.tif.
Mask dtype is uint8: background=0, foreground=255; size=1200x1200.
Model: frozen baseline Mito 2D U-Net, cross-validation fold 0 checkpoint.
Checkpoint SHA256: 66db8edc3006a9b70fdd75901f6f5e4a40359699f7a372d28f054d8dec58ecd3
Threshold: 0.45, selected on fold-0 validation data.
Inference: per-image 1–99.8 percentile normalization; 512x512 overlapping
sliding-window tiles with 128-pixel overlap and probability blending.
RunPod environment: Python 3.11.17, TensorFlow 2.21.0, one NVIDIA A40.
See prediction_manifest.json for one-to-one filenames and mask fractions.
The new organoid images have no manual masks here, so external Dice/accuracy
cannot be measured. Review predictions before treating them as scientific labels.
Do not add these predictions to the 36 manually labelled training pairs as if
human annotations without a separate review and data-version decision.
