Automated Mito 2D semantic segmentation predictions for cell_22383_140

These 140 TIFFs are model-generated masks, not manually verified ground truth.
Each Mito_NNN.tif corresponds pixel-for-pixel to ../Mito/Mito_NNN.tif.
Each mask is 1200 x 1200 uint8: background=0, foreground=255.
Model: frozen baseline Mito 2D U-Net, cross-validation fold-0 checkpoint.
Checkpoint SHA256: 66db8edc3006a9b70fdd75901f6f5e4a40359699f7a372d28f054d8dec58ecd3
Threshold: 0.45, selected on fold-0 validation data.
Inference: per-image 1-99.8 percentile normalization; 512 x 512 tiles,
128-pixel overlap, and blended probabilities on one NVIDIA A40.
See prediction_manifest.json for source names and mask foreground fractions.
The new organoid images have no manual masks here, so their true Dice cannot
be measured. Review predictions before treating them as scientific labels.
Do not mix these predictions into the 36 manually labelled training pairs as
human annotations without a separate review and data-version decision.
