Nuc 2D model predictions for expert review; these are not manual labels.
Unzip into a new location to avoid replacing existing results.
Each mask matches its fluo source filename and 1200x1200 pixel grid.
Single-channel uint8: background 0 (black), nucleus 255 (white).
Run `shasum -a 256 -c SHA256SUMS.txt` from this Nuc_label folder.
